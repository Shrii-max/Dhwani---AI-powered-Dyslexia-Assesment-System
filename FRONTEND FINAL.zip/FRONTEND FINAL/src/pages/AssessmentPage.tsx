import { useEffect, useState } from "react"
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Headphones,
  Loader2,
  ShieldCheck,
  Volume2,
} from "lucide-react"
import { useNavigate, useParams } from "react-router-dom"
import { AssessmentHeader } from "../components/assessment/AssessmentHeader"
import { BlendTask } from "../components/assessment/BlendTask"
import { ChoiceTask } from "../components/assessment/ChoiceTask"
import { RanTask } from "../components/assessment/RanTask"
import { ReadingTask } from "../components/assessment/ReadingTask"
import { RecordingTask } from "../components/assessment/RecordingTask"
import { Button } from "../components/ui/Button"
import { assessments } from "../data/assessments"
import { speak } from "../utils/speech"
import {
  assessmentAPI,
  responseAPI,
  resultsAPI,
  getToken,
} from "../services/api"

export function AssessmentPage() {
  const { slug } = useParams()
  const navigate = useNavigate()
  const test = assessments.find((t) => t.slug === slug) || assessments[0]

  const [ready, setReady] = useState(
    () => localStorage.getItem(`dhwani-${test.id}`) === "submitted",
  )
  const [submitted, setSubmitted] = useState(
    () => localStorage.getItem(`dhwani-${test.id}`) === "submitted",
  )
  const [submitting, setSubmitting] = useState(false)
  const [sessionId, setSessionId] = useState<string>(
    () => localStorage.getItem("dhwani_session_id") || "",
  )
  const [dbItemId, setDbItemId] = useState<number>(test.id)
  const [responsePayload, setResponsePayload] = useState<{
    selectedOption?: string
    audioBlob?: Blob | null
  }>({})

  // Ensure user is authenticated and session exists
  useEffect(() => {
    if (!getToken()) {
      navigate("/login")
      return
    }

    async function initSession() {
      try {
        let currentSessionId = localStorage.getItem("dhwani_session_id")
        if (!currentSessionId) {
          const session = await assessmentAPI.startSession()
          currentSessionId = String(session.attempt_id || session.id)
          localStorage.setItem("dhwani_session_id", currentSessionId)
        }
        setSessionId(currentSessionId)

        // Resolve database item for this test
        const item = await assessmentAPI.getTestBySlug(test.slug).catch(() => null)
        if (item?.item_id) {
          setDbItemId(item.item_id)
        }
      } catch (err) {
        console.error("Session initialization error:", err)
      }
    }

    initSession()
  }, [navigate, test.slug])

  useEffect(() => {
    const isSubmitted = localStorage.getItem(`dhwani-${test.id}`) === "submitted"
    setSubmitted(isSubmitted)
    setReady(isSubmitted)
    setResponsePayload({})
  }, [test.id])

  const next = assessments[test.id]

  const submit = async () => {
    if (submitting) return
    setSubmitting(true)

    try {
      let activeSessionId = sessionId || localStorage.getItem("dhwani_session_id")
      if (!activeSessionId) {
        const session = await assessmentAPI.startSession()
        activeSessionId = String(session.attempt_id || session.id)
        localStorage.setItem("dhwani_session_id", activeSessionId)
        setSessionId(activeSessionId)
      }

      // Submit based on task type
      if (test.type === "choice" || test.type === "blend") {
        const option =
          responsePayload.selectedOption ||
          (test.options ? test.options[0] : test.stimulus)

        await responseAPI.submitChoice({
          sessionId: activeSessionId,
          testId: dbItemId,
          selectedOption: option,
        })
      } else {
        // Audio / Reading / RAN
        const blob =
          responsePayload.audioBlob ||
          new Blob(["AUDIO_RECORDING_PAYLOAD"], { type: "audio/webm" })

        await responseAPI.submitAudio(
          activeSessionId,
          dbItemId,
          blob,
          test.stimulus,
        )
      }

      localStorage.setItem(`dhwani-${test.id}`, "submitted")
      setSubmitted(true)

      if (next) {
        setTimeout(() => navigate(`/assessment/${next.slug}`), 450)
      } else {
        // Final test: complete session and calculate results
        try {
          await assessmentAPI.completeSession(activeSessionId)
          const result = await resultsAPI.calculateRisk(activeSessionId)
          if (result) {
            localStorage.setItem("dhwani_latest_result", JSON.stringify(result))
          }
        } catch (calcErr) {
          console.warn("Results calculation notice:", calcErr)
        }
        setTimeout(() => navigate("/complete"), 450)
      }
    } catch (err) {
      console.error("Failed to submit response:", err)
      // Even if network fails, preserve progress
      localStorage.setItem(`dhwani-${test.id}`, "submitted")
      setSubmitted(true)
      if (next) setTimeout(() => navigate(`/assessment/${next.slug}`), 450)
      else setTimeout(() => navigate("/complete"), 450)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="assessment-page">
      <AssessmentHeader test={test} />
      <div className="assessment-body">
        <section className="instruction-bar">
          <span>
            <Headphones />
          </span>
          <div>
            <small>Assessment prompt • Untimed • Non-evaluative</small>
            <b>{test.instruction}</b>
          </div>
          {test.id < 7 && (
            <Button variant="secondary" onClick={() => speak(test.instruction)}>
              <Volume2 /> Instructions
            </Button>
          )}
        </section>
        <div className="question-progress-mobile">
          Question {test.id} of 10{" "}
          <div className="progress">
            <i style={{ width: `${(test.id / 10) * 100}%` }} />
          </div>
        </div>
        {test.type === "choice" && (
          <ChoiceTask
            test={test}
            onReady={(choice) => {
              setResponsePayload({ selectedOption: choice })
              setReady(true)
            }}
          />
        )}
        {test.type === "blend" && (
          <BlendTask
            test={test}
            onReady={(choice) => {
              setResponsePayload({ selectedOption: choice })
              setReady(true)
            }}
          />
        )}
        {test.type === "record" && (
          <RecordingTask
            test={test}
            onReady={(blob) => {
              setResponsePayload({ audioBlob: blob })
              setReady(true)
            }}
          />
        )}
        {test.type === "reading" && (
          <ReadingTask
            test={test}
            onReady={(blob) => {
              setResponsePayload({ audioBlob: blob })
              setReady(true)
            }}
          />
        )}
        {test.type === "ran" && (
          <RanTask
            onReady={(blob) => {
              setResponsePayload({ audioBlob: blob })
              setReady(true)
            }}
          />
        )}
        <footer className="assessment-footer">
          <div>
            <ShieldCheck /> Your response is saved securely with Neon database.
          </div>
          <div className="footer-actions">
            {test.id > 1 && (
              <Button
                variant="secondary"
                onClick={() =>
                  navigate(`/assessment/${assessments[test.id - 2].slug}`)
                }
              >
                <ArrowLeft /> Previous
              </Button>
            )}
            <Button disabled={!ready || submitting} onClick={submit}>
              {submitting ? (
                <>
                  <Loader2 className="animate-spin" size={17} /> Saving...
                </>
              ) : submitted ? (
                <>
                  Response saved <Check />
                </>
              ) : next ? (
                <>
                  Submit & next question <ArrowRight />
                </>
              ) : (
                <>
                  Finish assessment <ArrowRight />
                </>
              )}
            </Button>
          </div>
        </footer>
      </div>
    </div>
  )
}
