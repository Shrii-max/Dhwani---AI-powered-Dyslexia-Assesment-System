import { useEffect, useState } from "react"
import { Check, ChevronRight } from "lucide-react"
import { Link } from "react-router-dom"
import { AppShell } from "../components/layout/AppShell"
import { assessments } from "../data/assessments"
import { dashboardAPI } from "../services/api"

export function AssessmentsPage() {
  const [completedCount, setCompletedCount] = useState<number>(() => {
    let count = 0
    assessments.forEach((t) => {
      if (localStorage.getItem(`dhwani-${t.id}`) === "submitted") {
        count++
      }
    })
    return count
  })

  useEffect(() => {
    async function loadProgress() {
      try {
        const prog = await dashboardAPI.getProgress()
        if (prog && typeof prog.completedTests === "number") {
          setCompletedCount(prog.completedTests)
        }
      } catch (err) {
        console.error("Failed to load assessment progress:", err)
      }
    }
    loadProgress()
  }, [])

  return (
    <AppShell>
      <div className="page">
        <div className="page-title">
          <span className="eyebrow">Assessment pathway</span>
          <h1>Ten activities, one clear picture</h1>
          <p>Your responses are saved securely to Neon database as you progress.</p>
        </div>
        <div className="test-list">
          {assessments.map((t, i) => {
            const isDone =
              i < completedCount ||
              localStorage.getItem(`dhwani-${t.id}`) === "submitted"
            const isCurrent = i === completedCount

            return (
              <Link
                to={`/assessment/${t.slug}`}
                className="test-row"
                key={t.slug}
              >
                <span
                  className={`test-number ${
                    isDone ? "done" : isCurrent ? "current" : ""
                  }`}
                >
                  {isDone ? <Check size={18} /> : i + 1}
                </span>
                <div>
                  <small>{t.category}</small>
                  <b>{t.title}</b>
                  <p>{t.instruction}</p>
                </div>
                <span className="test-meta">
                  {t.type === "choice"
                    ? "Choose"
                    : t.type === "ran"
                      ? "Timed grid"
                      : "Record"}{" "}
                  <ChevronRight size={17} />
                </span>
              </Link>
            )
          })}
        </div>
      </div>
    </AppShell>
  )
}
