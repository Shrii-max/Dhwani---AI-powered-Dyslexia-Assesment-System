import { Router, Response } from 'express';
import prisma from '../config/database';
import {
  authenticate,
  AuthRequest,
  requireStudent
} from '../middleware/auth.middleware';
import { AppError } from '../middleware/errorHandler';

const router = Router();

// Mapping for frontend slugs to subskills/sections
const slugMap: Record<string, { section?: string; subskill?: string; promptKeyword?: string }> = {
  'phoneme-identification': { section: 'phonological_awareness', subskill: 'phoneme_identification' },
  'phoneme-matching': { section: 'phonological_awareness', subskill: 'phoneme_matching' },
  'phoneme-blending': { section: 'phonological_awareness', subskill: 'phoneme_blending' },
  'phoneme-segmentation': { section: 'phonological_awareness', subskill: 'phoneme_segmentation' },
  'phoneme-deletion': { section: 'phonological_awareness', subskill: 'phoneme_deletion' },
  'phoneme-substitution': { section: 'phonological_awareness', subskill: 'phoneme_substitution' },
  'regular-word-reading': { section: 'word_reading', subskill: 'regular_words' },
  'irregular-word-reading': { section: 'word_reading', subskill: 'irregular_words' },
  'pseudoword-reading': { section: 'word_reading', subskill: 'pseudowords' },
  'rapid-naming': { section: 'rapid_naming', subskill: 'ran_objects' },
};

// Start new assessment attempt (session)
router.post(
  '/session',
  authenticate,
  requireStudent,
  async (req: AuthRequest, res: Response, next) => {
    try {
      const studentId = parseInt(req.studentId!, 10);

      // Check if there's already an active in-progress session
      let attempt = await prisma.assessment_attempts.findFirst({
        where: {
          student_id: studentId,
          status: 'in_progress'
        },
        orderBy: { attempt_id: 'desc' }
      });

      if (!attempt) {
        attempt = await prisma.assessment_attempts.create({
          data: {
            student_id: studentId,
            status: 'in_progress'
          }
        });
      }

      res.status(201).json({
        success: true,
        message: 'Assessment session started',
        data: {
          attempt,
          session: attempt
        }
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get attempt details
router.get(
  '/session/:attemptId',
  authenticate,
  async (req: AuthRequest, res: Response, next) => {
    try {
      const rawAttemptId = req.params.attemptId;
      const attemptId = Array.isArray(rawAttemptId)
        ? rawAttemptId[0]
        : rawAttemptId;

      if (!attemptId || !/^\d+$/.test(attemptId)) {
        throw new AppError('Invalid assessment attempt ID', 400);
      }

      const attempt = await prisma.assessment_attempts.findUnique({
        where: { attempt_id: parseInt(attemptId, 10) },
        include: {
          student_responses: {
            include: {
              item_bank: true,
              audio_recordings: true
            }
          }
        }
      });

      if (!attempt) {
        throw new AppError('Assessment attempt not found', 404);
      }

      // Check authorization
      if (
        req.studentId &&
        attempt.student_id !== parseInt(req.studentId, 10)
      ) {
        throw new AppError('Unauthorized access', 403);
      }

      res.json({
        success: true,
        data: {
          attempt,
          session: attempt
        }
      });
    } catch (error) {
      next(error);
    }
  }
);

// Complete assessment attempt
router.patch(
  '/session/:attemptId/complete',
  authenticate,
  requireStudent,
  async (req: AuthRequest, res: Response, next) => {
    try {
      const rawAttemptId = req.params.attemptId;
      const attemptId = Array.isArray(rawAttemptId)
        ? rawAttemptId[0]
        : rawAttemptId;

      if (!attemptId || !/^\d+$/.test(attemptId)) {
        throw new AppError('Invalid assessment attempt ID', 400);
      }

      const attempt = await prisma.assessment_attempts.findUnique({
        where: { attempt_id: parseInt(attemptId, 10) }
      });

      if (!attempt) {
        throw new AppError('Assessment attempt not found', 404);
      }

      if (attempt.student_id !== parseInt(req.studentId!, 10)) {
        throw new AppError('Unauthorized access', 403);
      }

      const updatedAttempt = await prisma.assessment_attempts.update({
        where: { attempt_id: parseInt(attemptId, 10) },
        data: {
          status: 'completed',
          completed_at: new Date()
        }
      });

      res.json({
        success: true,
        message: 'Assessment completed',
        data: {
          attempt: updatedAttempt,
          session: updatedAttempt
        }
      });
    } catch (error) {
      next(error);
    }
  }
);

// Get assessment test by slug or id
router.get('/:slug', authenticate, async (req: AuthRequest, res: Response, next) => {
  try {
    const rawSlug = req.params.slug;
    const slug = String(Array.isArray(rawSlug) ? rawSlug[0] : rawSlug);

    // Check if numeric item_id
    if (/^\d+$/.test(slug)) {
      const item = await prisma.item_bank.findUnique({
        where: { item_id: parseInt(slug, 10) }
      });
      if (item) {
        return res.json({
          success: true,
          data: { test: item, item }
        });
      }
    }

    const mapping = slugMap[slug];
    let item = null;

    if (mapping) {
      // Find matching item in item_bank
      item = await prisma.item_bank.findFirst({
        where: {
          section: mapping.section,
          subskill: mapping.subskill,
          active: true
        }
      });
    }

    if (!item) {
      // Fallback search by prompt or section
      item = await prisma.item_bank.findFirst({
        where: {
          active: true,
          OR: [
            { section: { contains: slug.replace(/-/g, '_'), mode: 'insensitive' } },
            { subskill: { contains: slug.replace(/-/g, '_'), mode: 'insensitive' } }
          ]
        }
      });
    }

    if (!item) {
      throw new AppError(`Assessment test not found for slug: ${slug}`, 404);
    }

    res.json({
      success: true,
      data: {
        test: item,
        item
      }
    });
  } catch (error) {
    next(error);
  }
});

// Get all assessment items from item_bank
router.get('/', authenticate, async (req: AuthRequest, res: Response, next) => {
  try {
    const items = await prisma.item_bank.findMany({
      where: {
        active: true,
        is_practice: false
      },
      orderBy: { item_id: 'asc' }
    });

    res.json({
      success: true,
      data: {
        items,
        tests: items
      }
    });
  } catch (error) {
    next(error);
  }
});

export default router;
